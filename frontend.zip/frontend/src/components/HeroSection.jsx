import React from 'react';

const HeroSection = () => {
  return (
    <div className="hero bg-blue-500 text-white py-16">
      <div className="max-w-6xl mx-auto text-center">
        <h1 className="text-5xl font-bold mb-4">Welcome to TheCipher</h1>
        <p className="text-xl mb-8">Explore the latest posts and updates</p>
        <a href="/posts" className="bg-white text-blue-500 px-6 py-3 rounded-full font-semibold">Explore Posts</a>
      </div>
    </div>
  );
};

export default HeroSection;
