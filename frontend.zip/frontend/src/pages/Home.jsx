import React from 'react';
import PostList from '../components/PostList';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HeroSection from '../components/HeroSection';


const Home = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      
      <HeroSection />
      <div className="max-w-6xl mx-auto mt-6 p-4">
        <h2 className="text-3xl font-bold mb-6 text-center">Latest Posts</h2>
        <PostList />
      </div>
      <Footer />
    </div>
  );
};

export default Home;
